# https://wiki.strongswan.org/projects/strongswan/wiki/Kernel-libipsec
# 1.当使用libipsec作为host-host隧道时，由strongswan管理路由，开启kernel-netlink中的fwmark，表示仅对于fwmark不为0x42的包做路由，也就是使其通过tunnel发送
# 2.socket-default中配置的fwmark表示为所有IKE表添加0x42标志，防止被strongswan路由，可以不走tunnel直接到达对端
# 3.需要开启内核对数据包的过滤，防止数据包回环
# 4.libipsec只支持tunnel模式
# 5.不使用libipsec时，tunnel和tranport都能建立，但是无法通信，抓包发现接收时数据包损坏，有待分析原因
sysctl -w net.ipv4.conf.all.rp_filter=2

